Projecte fet amb el framework Vue.js

Obrir el fitxer index.html (el fitxer municipis.html s'obre desde el programa)

Els cercadors funcionen posant el nom exacte(amb majúscules i accents)