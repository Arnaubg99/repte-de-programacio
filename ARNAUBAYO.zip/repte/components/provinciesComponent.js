Vue.component('provincies-component',{
    template:`
    <div ref="main">
      <div>
        <nav ref="navbar" class="navbar navbar-expand-lg">
          <div class="container-fluid">
              <img src="./img/logoT.png" height="50"/>
              <a class="navbar-brand"></a>
              <button type="button" class="btn btn-secondary" v-if="modeFosc" @click="setModeFosc()"><i class="fal fa-moon">  Modo Oscuro: ON</i></button>
              <button type="button" class="btn btn-secondary" v-else @click="setModeFosc()"><i class="fal fa-sun">  Modo Oscuro: OFF</i></button>
          </div>
        </nav>
        <div ref="card" class="card m-3 fons" id="centrarElements">
          <h4 class="card-title mt-2">Províncias</h4>
          <div id="centrarElements">
          <div class="container-fluid">
              <form class="d-flex">
                  <input class="form-control me-2" type="search" v-model="buscarPerNom" placeholder="Nombre Província" aria-label="Buscar">
                  <button class="btn btn-success" @click="buscarPerNomProvincia()" type="button">Buscar</button>
              </form>
              <button class=" btn btn-danger m-4" v-if="filtres" @click="anularCerca()" type="button">Anular Búsqueda</button>

          </div>
            <a class="btn btn-success mt-3"><i class="far fa-filter" data-target="#modalFiltres" @click="obrirModalFiltres()">  Filtros</i></a>
          </div>
          <div class="row col-12">
            <div v-for="provincia in provincies" :key="provincia.CODPROV" id="centrarElements" class="col-md-6 col-lg-4 col-sm-8 col-xs-10 ml-2">
              <card-provincies-component v-bind:modeFosc="modeFosc" v-bind:provincia="provincia"></card-provincies-component>
            </div>
          </div>
        </div>
      </div>
      <!-- MODAL FILTRES -->
          <div class="modal fade" ref="modalFiltres" id="modalFiltres" aria-labelledby="modalAdjLabel" role="dialog" tabindex="-1" aria-hidden="true">
              <div class="modal-dialog modal-lg" role="document">
                  <div class="modal-content">
                      <div class="modal-header">
                          <h5 class="modal-title" id="centrarElements"><i class="fal fa-cog fa-1x"></i>  Filtros</h5>
                          <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>  
                      </div>
                      <div class="modal-body">
                        <h5 class="modal-title">Ordenar las províncias por: </h5>
                        <div class="row ml-3">
                            <div class="form-check form-check-inline">
                                <input class="form-check-input" type="radio" name="radiosOrdenar"  id="alfabeticA" @click="ordenar(1)">
                                <label class="form-check-label" for="alfabeticA">
                                    Orden alfabético (A-Z)
                                </label>
                            </div>
                            <div class="form-check form-check-inline">
                                <input class="form-check-input" type="radio" name="radiosOrdenar"  id="alfabeticZ" @click="ordenar(2)">
                                <label class="form-check-label" for="alfabeticZ">
                                    Orden alfabético (Z-A)
                                </label>
                            </div>
                        </div>
                      </div>
                  </div>
              </div>
          </div>
    </div>
  `,

  data () {
    return {
      provincies:[],
      totesProvincies:[],
      error: '',
      modeFosc: false,
      filtres: false,
      buscarPerNom: '',
    }

  },

  methods:{
    //Recull totes les províncies de la API
    selectProvincies(){
      let me = this;
      axios
      .get('https://www.el-tiempo.net/api/json/v2/provincias')
      .then(response => {
        var provincies = response.data;
        me.provincies = provincies.provincias;
        me.totesProvincies = provincies.provincias;

      })
      .catch(error => {
        console.log(error)
        me.error = "No s'han pogut carregar les províncies.";
      })
    },

    //Recull totes les poblacions de la API que tinguin com a província la que es passa per paràmetre
    selectPoblacionsProvincia(idProvincia){
      let me = this;
      axios
      .get('https://www.el-tiempo.net/api/json/v2/provincias/'+idProvincia+'/municipios')
      .then(response => {
        me.provincies = response.data;
      })
      .catch(error => {
        console.log(error)
        me.error = "No s'han pogut carregar les províncies.";
      })
    },
    //Obre el modal dels filtres
    obrirModalFiltres(){
        var modalFiltres = new bootstrap.Modal(document.getElementById('modalFiltres'), {
          keyboard: false
        })
        modalFiltres.show()
    },
    //Activar mode fosc i crea la sessió de mode fosc
    setModeFosc(){
        if(this.modeFosc == true){
            this.modeFosc = false;
        }else{
            this.modeFosc = true;
        };
        this.activarModeFosc();
        sessionStorage.setItem('modeFosc', this.modeFosc);
    },
    activarModeFosc(){
        var r = document.querySelector(':root');

        if( this.modeFosc == false) {
            this.$refs.main.classList.remove( "fosc" );
            this.$refs.navbar.classList.remove( "fosc" );
            this.$refs.card.classList.remove( "fosc" );
            this.$refs.card.classList.add( "fons" );
            this.$refs.modalFiltres.classList.remove( "foscModal" );
            r.style.setProperty('--bgcolor', 'rgba(123,164,204,1)');
            r.style.setProperty('--navcolor', 'rgba(90, 147, 204, 1)');
        } else {
            this.$refs.main.classList.add( "fosc" );
            this.$refs.navbar.classList.add( "fosc" );
            this.$refs.card.classList.remove( "fons" );
            this.$refs.card.classList.add( "fosc" );
            this.$refs.modalFiltres.classList.add( "foscModal" );
            r.style.setProperty('--bgcolor', 'rgba(0,56,81,1)');
            r.style.setProperty('--navcolor', 'rgba(0,37,53,1)');
        }
    },
     //Troba la sessió del mode fosc, si la troba passa el seu valor a la variable local
     trobarSessioModeFosc(){
      var modeFoscResult = this.getValorSessio('modeFosc');
      if(modeFoscResult != null){
          var modeFoscBoolean = (modeFoscResult == "true");
          this.modeFosc = modeFoscBoolean;
      }
    },
    //Busca la sessió amb el nom que se li passa per paràmetre i retorna el valor
    getValorSessio(nomSessio){
        return sessionStorage.getItem(nomSessio);
    },
    //Ordenar les provínices
    ordenar(valor){
      switch(valor){
        case 1:
          this.ordenarPerOrdreAlfabeticAZ();
        break;
        case 2:
          this.ordenarPerOrdreAlfabeticZA();
        break;
      }
    },
    //Ordena les provincies per ordre alfabètic
    ordenarPerOrdreAlfabeticAZ(){
      this.provincies.sort(function(a,b) {
        if (a.NOMBRE_PROVINCIA < b.NOMBRE_PROVINCIA)
           return -1;
        if (a.NOMBRE_PROVINCIA > b.NOMBRE_PROVINCIA)
          return 1;
        return 0;
      });
    },
    //Ordena les provincies per ordre alfabètic (Z-A)
    ordenarPerOrdreAlfabeticZA(){
      this.provincies.sort(function(a,b) {
        if (a.NOMBRE_PROVINCIA > b.NOMBRE_PROVINCIA)
           return -1;
        if (a.NOMBRE_PROVINCIA < b.NOMBRE_PROVINCIA)
          return 1;
        return 0;
      });
    },
    //Buscar la provincia per nom; si el nom d'alguna provincia encaixa amb el valor introduit, el mostrarà
    buscarPerNomProvincia(){
      var buscarPerNom = this.buscarPerNom;
      var totesProvincies = this.totesProvincies;
      var provincies = [];
      var trobada = false;
      var filtres = false;
      var i = 0;
      //Quan ha trobat la provincia deixa de recorrer l'array
      while(i < totesProvincies.length && trobada == false){
        if(totesProvincies[i].NOMBRE_PROVINCIA == buscarPerNom){
          provincies.push(totesProvincies[i])
            filtres = true
            trobada = true
        }
        i++;
      }
      //Si no ha trobat la provincia carrega dins l'array totes les provincies
      if(trobada == false){
        provincies = totesProvincies
      }
      this.provincies = provincies
      this.filtres = filtres
    },
    //Reestableix l'array de provincies
    anularCerca(){
        this.provincies = this.totesProvincies
        this.filtres = false
    }
  },
  created(){
    this.selectProvincies();
    this.trobarSessioModeFosc();
  },
  mounted(){
    this.activarModeFosc();
  }
})

var app = new Vue({
    el: '#app',
    data: {
      message: 'Hello Vue!'
    },
    components:{
    }
  })

