Vue.component('municipis-component',{
    template:`
  <div ref="main">
    <div>
      <nav ref="navbar" class="navbar navbar-expand-lg">
        <div class="container-fluid">
            <img src="./img/logoT.png" height="50"/>
            <a class="navbar-brand"></a>
            <button type="button" class="btn btn-secondary" v-if="modeFosc" @click="setModeFosc()"><i class="fal fa-moon">  Modo Oscuro: ON</i></button>
            <button type="button" class="btn btn-secondary" v-else @click="setModeFosc()"><i class="fal fa-sun">  Modo Oscuro: OFF</i></button>
        </div>
      </nav>
      <div ref="card" class="card m-3 fons" id="centrarElements">
        <h4 class="card-title mt-2">Municipios</h4>
        <div id="centrarElements">
            <div class="container-fluid">
                <form class="d-flex">
                    <input class="form-control me-2" type="search" v-model="buscarPerNom" placeholder="Nombre Municipio" aria-label="Buscar">
                    <button class="btn btn-success" @click="buscarPerNomMunicipi()" type="button">Buscar</button>
                </form>
                <button class="btn btn-danger m-3" v-if="filtres" @click="anularCerca()" type="button">Anular Búsqueda</button>
            </div>
          <a class="btn btn-success mt-3"><i class="far fa-filter" data-target="#modalFiltres" @click="obrirModalFiltres()">  Filtros</i></a>
        </div>
        <div class="row col-12">
          <div v-for="municipi in municipis" :key="municipi.CODIGOINE" id="centrarElements" class="col-md-6 col-lg-4 col-sm-8 col-xs-10 ml-2">
            <card-municipis-component v-bind:municipi="municipi"></card-municipis-component>
          </div>
        </div>
      </div>
    </div>
    <!-- MODAL FILTRES -->
        <div class="modal fade" ref="modalFiltres" id="modalFiltres" aria-labelledby="modalAdjLabel" role="dialog" tabindex="-1" aria-hidden="true">
            <div class="modal-dialog modal-lg" role="document">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title" id="centrarElements"><i class="fal fa-cog fa-1x"></i>  Filtros</h5>
                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>                        
                    </div>
                    <div class="modal-body">
                        <h5 class="modal-title">Ordenar las municipios por: </h5>
                        <div class="row ml-3">
                            <div class="form-check form-check-inline">
                                <input class="form-check-input" type="radio" name="radiosOrdenar"  id="alfabeticA" @click="ordenar(1)">
                                <label class="form-check-label" for="alfabeticA">
                                    Orden alfabético (A-Z)
                                </label>
                            </div>
                            <div class="form-check form-check-inline">
                                <input class="form-check-input" type="radio" name="radiosOrdenar"  id="alfabeticZ" @click="ordenar(2)">
                                <label class="form-check-label" for="alfabeticZ">
                                    Orden alfabético (Z-A)
                                </label>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
  </div>
`,

  data () {
    return {
      municipis:[],
      totsMunicipis:[],
      codProv:'',
      error: '',
      modeFosc: false,
      buscarPerNom:'',
      filtres: false,
    }

  },

  methods:{
    //Recull totes els municipis de la provincia escollida de la API
    selectMunicipis(idMunicipi){
      let me = this;
      axios
      .get('https://www.el-tiempo.net/api/json/v2/provincias/'+idMunicipi+'/municipios')
      .then(response => {
        var municipis = response.data;
        me.municipis = municipis.municipios;
        me.totsMunicipis = municipis.municipios;
      })
      .catch(error => {
        console.log(error)
        me.error = "No s'han pogut carregar els municipis.";
      })
    },
    
    //Obre el modal dels filtres
    obrirModalFiltres(){
        var modalFiltres = new bootstrap.Modal(document.getElementById('modalFiltres'), {
          keyboard: false
        })
        modalFiltres.show()
    },
    //Canvia la variable de modeFosc, activa el mode fosc i crea la sessio de mode fosc
    setModeFosc(){
        if(this.modeFosc == true){
            this.modeFosc = false;
        }else{
            this.modeFosc = true;
        };
        this.activarModeFosc();
        sessionStorage.setItem('modeFosc', this.modeFosc);
    },
    //Activar el mode fosc
    activarModeFosc(){
        var r = document.querySelector(':root');
        if( this.modeFosc == false) {
            this.$refs.main.classList.remove( "fosc" );
            this.$refs.navbar.classList.remove( "fosc" );
            this.$refs.card.classList.remove( "fosc" );
            this.$refs.card.classList.add( "fons" );
            this.$refs.modalFiltres.classList.remove( "foscModal" );
            r.style.setProperty('--bgcolor', 'rgba(123,164,204,1)');
            r.style.setProperty('--navcolor', 'rgba(90, 147, 204, 1)');
        } else {
            this.$refs.main.classList.add( "fosc" );
            this.$refs.navbar.classList.add( "fosc" );
            this.$refs.card.classList.remove( "fons" );
            this.$refs.card.classList.add( "fosc" );
            this.$refs.modalFiltres.classList.add( "foscModal" );
            r.style.setProperty('--bgcolor', 'rgba(0,56,81,1)');
            r.style.setProperty('--navcolor', 'rgba(0,37,53,1)');
        }
    },
    //Troba la sessió del codi de la província, si troba passa el seu valor a la variable local
    trobarSessioCodiProvincia(){
        var codProvResult = this.getValorSessio('codProv');
        if(codProvResult != null){
            this.codProv = codProvResult;
        }
    },
    //Troba la sessió del mode fosc, si la troba passa el seu valor a la variable local
    trobarSessioModeFosc(){
        var modeFoscResult = this.getValorSessio('modeFosc');
        if(modeFoscResult != null){
            var modeFoscBoolean = (modeFoscResult == "true");
            this.modeFosc = modeFoscBoolean;
        }
    },
    //Busca la variable de sessió amb el nom que se li passa per paràmetre i si la troba retorna el valor, si la troba retorna null
    getValorSessio(nomSessio){
        return sessionStorage.getItem(nomSessio);
    },

     //Ordenar els municipis
     ordenar(valor){
        switch(valor){
          case 1:
            this.ordenarPerOrdreAlfabeticAZ();
          break;
          case 2:
            this.ordenarPerOrdreAlfabeticZA();
          break;
        }
      },
      //Ordena els municipis per ordre alfabètic (A-Z)
      ordenarPerOrdreAlfabeticAZ(){
        this.municipis.sort(function(a,b) {
          if (a.NOMBRE < b.NOMBRE)
             return -1;
          if (a.NOMBRE > b.NOMBRE)
            return 1;
          return 0;
        });
      },
      //Ordena els municipis per ordre alfabètic (Z-A)
      ordenarPerOrdreAlfabeticZA(){
        this.municipis.sort(function(a,b) {
          if (a.NOMBRE > b.NOMBRE)
             return -1;
          if (a.NOMBRE < b.NOMBRE)
            return 1;
          return 0;
        });
      },
      //Buscar municipi per nom; si el nom d'algun municipi encaixa amb el valor introduit, el mostrarà
      buscarPerNomMunicipi(){
          var buscarPerNom = this.buscarPerNom;
          var municipis = [];
          var totsMunicipis = this.totsMunicipis;
          var trobat = false
          var filtres = false;
          i = 0;
          //Quan ha trobat el municipi deixa de recorrer l'array
          while(i < totsMunicipis.length && trobat == false){
            if(totsMunicipis[i].NOMBRE == buscarPerNom){
              municipis.push(totsMunicipis[i])
              filtres = true
              trobat = true
            }
            i++;
          }
          //Si no ha trobat el municipi carrega dins l'array tots els municipis
          if(trobat == false){
              municipis = totsMunicipis
          }
            this.municipis = municipis
            this.filtres = filtres
      },
      //Reestableix l'array de municipis
      anularCerca(){
          this.municipis = this.totsMunicipis
          this.filtres = false
      }
  },
  created(){
    this.trobarSessioCodiProvincia();
    this.trobarSessioModeFosc();
    this.selectMunicipis(this.codProv);
  },
  mounted(){
    this.activarModeFosc();
  }
})

var app = new Vue({
    el: '#app',
    data: {
      message: 'Hello Vue!'
    },
  })

