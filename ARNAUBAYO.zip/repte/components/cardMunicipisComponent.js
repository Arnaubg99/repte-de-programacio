Vue.component('card-municipis-component',{
    template:`
  <div class="row justify-content-center" id="cardCss">
    <div class="card m-2 tamanyCard" style="width: 18rem;" id="cardCos">
      <div class="card-body" id="cardBody">
        <h5 class="card-title">{{municipi.NOMBRE}}</h5>
        <h6 class="card-subtitle mb-2 text-muted"></h6>
        <div class="scrollTextMunicipis">
          <p class="card-text">Población: {{municipi.POBLACION_MUNI}}</p>
          <p class="card-text" v-if="temps.length != 0"> Fecha: {{temps.fecha}}</p>
          <p class="card-text" v-else>Fecha: Indefinido</p>
          <p class="card-text" v-if="temps.length != 0">Cielo: {{temps.stateSky.description}}</p>
          <p class="card-text" v-else>Cielo: Indefinido</p>
          <p class="card-text" v-if="temps.length != 0">Temperatura Actual: {{temps.temperatura_actual}} grados</p>
          <p class="card-text" v-else>Temperatura Actual: Indefinida</p>
          <p class="card-text" v-if="temps.length != 0">Temperatura Mínima: {{temps.temperaturas.min}} grados</p>
          <p class="card-text" v-else>Temperatura Mínima: Indefinida</p>
          <p class="card-text" v-if="temps.length != 0">Temperatura Máxima: {{temps.temperaturas.max}} grados</p>
          <p class="card-text" v-else>Temperatura Máxima: Indefinida</p>
          <p class="card-text" v-if="temps.length != 0">Humedad: {{temps.humedad}}%</p>
          <p class="card-text" v-else>Humedad: Indefinida</p>
        </div>
      </div>
    </div>
  </div>
`,
  props:{
    municipi:{
      type: Object,
      required: true,
    },
  },
  data () {
    return {
      temps:[],
      error: '',
    }
  },
  methods:{
    //Recull totes les poblacions de la API que tinguin com a província la que es passa per paràmetre
    selectTempsMunicipi(idProvincia, idMunicipi){
      let me = this;
      axios
      .get("https://www.el-tiempo.net/api/json/v2/provincias/"+idProvincia+"/municipios/"+idMunicipi)
      .then(response => {
         me.temps = response.data;
      })
      .catch(error => {
        console.log(error)
        me.error = "No se han podido cargar los datos del tiempo.";
      })
    },
    //Crea una sessio amb la provincia com a valor
    crearSessioCodProv(valor){
      sessionStorage.setItem('codProv', valor);
    }
  },
  created(){
    this.selectTempsMunicipi(this.municipi.CODPROV, this.municipi.COD_GEO);
  },
})
var app = new Vue({
    el: '#app',
    data: {
      message: 'Hello Vue!'
    }
  })

