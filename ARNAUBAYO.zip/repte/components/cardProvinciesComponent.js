Vue.component('card-provincies-component',{
    template:`
  <div class="row justify-content-center" id="cardCss">
    <div class="card m-2 tamanyCard" style="width: 18rem;" id="cardCos">
      <div class="card-body" id="cardBody">
        <h5 class="card-title">{{provincia.NOMBRE_PROVINCIA}}</h5>
        <h6 class="card-subtitle mb-2 text-muted">{{provincia.COMUNIDAD_CIUDAD_AUTONOMA}}</h6>
        <div class="scrollTextProvincies">
          <p class="card-text">Capital: {{provincia.CAPITAL_PROVINCIA}}</p>
          <p class="card-text" v-if="temps.length != 0">Tiempo de hoy: {{temps.today.p}}</p>
          <p class="card-text" v-else>Tiempo de hoy: Indefinido</p>
          <p class="card-text" v-if="temps.length != 0">Tiempo de mañana: {{temps.tomorrow.p}}</p>
          <p class="card-text" v-else>Tiempo de mañana: Indefinido</p>
        </div>
        <a href="./municipis.html" class="btn btn-primary mt-3" @click="crearSessioCodiProv(provincia.CODPROV)">Mirar los Municipios</a>
      </div>
    </div>
  </div>
`,
  props:{
    provincia:{
      type: Object,
      required: true,
    },
  },
  data () {
    return {
      temps:[],
      error: '',
    }
  },
  methods:{
    //Recull totes les poblacions de la API que tinguin com a província la que es passa per paràmetre
    selectTempsProvincia(idProvincia){
      let me = this;
      axios
      .get("https://www.el-tiempo.net/api/json/v2/provincias/"+idProvincia)
      .then(response => {
         me.temps = response.data;
      })
      .catch(error => {
        console.log(error)
        me.error = "No se han podido cargar los datos del tiempo.";
      })
    },
    //Crea la sessió amb el codi de la província com a valor 
    crearSessioCodiProv(idProvincia){
      sessionStorage.setItem('codProv', idProvincia);
    },
  },
  created(){
    this.selectTempsProvincia(this.provincia.CODPROV);
  },
})
var app = new Vue({
    el: '#app',
    data: {
      message: 'Hello Vue!'
    }
  })

